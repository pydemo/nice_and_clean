from instapy import InstaPy

insta_username = 'signerbusters'
insta_password = r"""mZphTk/a/gU8jEzoOWbkM4yxyb/wB96xbiFveSFJuOp/d6RJhJOI0iBXrlsLnBItntckiJ7FbtxJMXLvvwJryDUilBMTjYtwB;"""
username = 'signerbusters' #your username
password = "144Steuben;144"

# if you want to run this script on a server,
# simply add nogui=True to the InstaPy() constructor
session = InstaPy(username=username, password=password)
session.login()

# set up all the settings
if 0:
    session.set_relationship_bounds(enabled=True,
        potency_ratio=-1.21,
        delimit_by_numbers=True,
        max_followers=4590,
        max_following=5555,
        min_followers=45,
        min_following=77)
session.set_do_follow(enabled=False, percentage=50)
session.set_comments(["🔝🔝🔝", "👍"], media="Photo")
session.set_do_comment(enabled=False, percentage=80)
session.set_do_like(True, percentage=70)

session.interact_by_users(['signer.busters'], amount=3, randomize=True, media='Photo')
# end the bot session
session.end()